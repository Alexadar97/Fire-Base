import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../shared/customer.service';

declare var $;

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  showDetelteMessage:boolean
  constructor(private customerService:CustomerService) { }
  customerArray = [];
  ngOnInit() {
    this.customerService.getCustomer().subscribe(
      data=>{
        this.customerArray = data.map(item=>{
          return{
            $key:item.key,
            ...item.payload.val()
          }
        })
        console.log(this.customerArray)
      }
    )
  }
  deletevalue:any
  delete($key){
    $("#deletemodal").modal("show")
    this.deletevalue = $key
  }
confirmdelete(){
  this.customerService.deleteCustomer(this.deletevalue);
  this.showDetelteMessage = true
  setTimeout(()=>this.showDetelteMessage = false, 5000)
  $("#deletemodal").modal("hide")
}
}
