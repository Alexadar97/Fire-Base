

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyByoIPiEzCyuyzNerdLKx1Ig-xfWm513o0",
    authDomain: "fir-crud-4a531.firebaseapp.com",
    databaseURL: "https://fir-crud-4a531.firebaseio.com",
    projectId: "fir-crud-4a531",
    storageBucket: "",
    messagingSenderId: "354907566963",
    appId: "1:354907566963:web:606fd1aef973ceac"
  }
};

